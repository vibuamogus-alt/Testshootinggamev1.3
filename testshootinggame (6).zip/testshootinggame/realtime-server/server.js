'use strict';
// Testshootinggame: static file server + WebSocket room relay. No npm dependencies.
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = process.env.PORT || 3000;
const INDEX = path.join(__dirname, 'index.html');
const TARGET = 20;   // team kills needed to win
const MAX = 8;       // players per room (4 per team at most)
const MODES = ['tdm', 'dm', 'bomb'];
// mode: tdm (team deathmatch), dm (free for all, 5 min), bomb (defusal rounds)
const DEFCFG = { mode: 'tdm', perTeam: 4, time: 10, target: 20, rounds: 5, maxDm: 8 };
const SEC = () => Number(process.env.TSG_SEC_MS) || 1000;
const FREEZE = 10, ROUND = 115, BOMB = 40, ENDW = 5, DM_MIN = 5;

const server = http.createServer((req, res) => {
  const url = req.url.split('?')[0];
  if (url === '/' || url === '/index.html') {
    fs.readFile(INDEX, (err, data) => {
      if (err) { res.writeHead(500); res.end('Server error'); return; }
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-cache' });
      res.end(data);
    });
  } else if (url === '/healthz') {
    res.writeHead(200); res.end('ok');
  } else {
    res.writeHead(404); res.end('Not found');
  }
});


// ---- minimal RFC 6455 WebSocket (text frames only) ----
const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
class Sock {
  constructor(socket) {
    this.socket = socket; this.readyState = 1; this.buf = Buffer.alloc(0); this.h = {}; this.closed = false;
    socket.on('data', d => this._data(d));
    socket.on('close', () => this._closed());
    socket.on('error', () => this._closed());
  }
  on(ev, fn) { this.h[ev] = fn; return this; }
  _emit(ev, a) { if (this.h[ev]) this.h[ev](a); }
  _frame(op, payload) {
    if (this.closed) return;
    const len = payload.length;
    let h;
    if (len < 126) h = Buffer.from([0x80 | op, len]);
    else if (len < 65536) { h = Buffer.alloc(4); h[0] = 0x80 | op; h[1] = 126; h.writeUInt16BE(len, 2); }
    else { h = Buffer.alloc(10); h[0] = 0x80 | op; h[1] = 127; h.writeBigUInt64BE(BigInt(len), 2); }
    try { this.socket.write(Buffer.concat([h, payload])); } catch (e) { /* socket gone */ }
  }
  send(str) { if (this.readyState === 1) this._frame(1, Buffer.from(str)); }
  close() {
    if (this.readyState === 1) { this.readyState = 2; this._frame(8, Buffer.alloc(0)); }
    try { this.socket.end(); } catch (e) { /* ignore */ }
    setTimeout(() => { try { this.socket.destroy(); } catch (e) { /* ignore */ } }, 500);
  }
  _closed() {
    if (this.closed) return;
    this.closed = true; this.readyState = 3; this._emit('close');
  }
  _data(d) {
    this.buf = Buffer.concat([this.buf, d]);
    if (this.buf.length > 16384) { this.close(); return; }
    for (;;) {
      const b = this.buf;
      if (b.length < 2) return;
      const op = b[0] & 15, masked = !!(b[1] & 128);
      let len = b[1] & 127, off = 2;
      if (len === 126) { if (b.length < 4) return; len = b.readUInt16BE(2); off = 4; }
      else if (len === 127) { if (b.length < 10) return; len = Number(b.readBigUInt64BE(2)); off = 10; }
      if (len > 4096) { this.close(); return; }
      const need = off + (masked ? 4 : 0) + len;
      if (b.length < need) return;
      let payload = b.subarray(off + (masked ? 4 : 0), need);
      if (masked) {
        const mask = b.subarray(off, off + 4);
        payload = Buffer.from(payload);
        for (let i = 0; i < payload.length; i++) payload[i] ^= mask[i & 3];
      }
      this.buf = b.subarray(need);
      if (op === 8) { this.close(); return; }
      if (op === 9) { this._frame(10, payload); continue; }
      if (op === 1) this._emit('message', payload.toString('utf8'));
    }
  }
}
server.on('upgrade', (req, socket) => {
  const key = req.headers['sec-websocket-key'];
  if (!key || String(req.headers.upgrade || '').toLowerCase() !== 'websocket') { socket.destroy(); return; }
  const accept = crypto.createHash('sha1').update(key + GUID).digest('base64');
  socket.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' + accept + '\r\n\r\n');
  socket.setNoDelay(true);
  onConnection(new Sock(socket));
});
const rooms = new Map();
let nextId = 1;

function newCode() {
  const A = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
  let c;
  do { c = ''; for (let i = 0; i < 4; i++) c += A[Math.floor(Math.random() * A.length)]; } while (rooms.has(c));
  return c;
}
function send(ws, o) { if (ws.readyState === 1) ws.send(JSON.stringify(o)); }
function bcast(room, o, exceptId) {
  for (const p of room.players.values()) if (p.id !== exceptId) send(p.ws, o);
}
function listPlayers(room) {
  return [...room.players.values()].map(p => ({ id: p.id, name: p.name, team: p.team, kills: p.kills, deaths: p.deaths, skin: p.skin }));
}
function leftSec(room) {
  return room.state === 'playing' && room.endsAt ? Math.max(0, Math.ceil((room.endsAt - Date.now()) / 1000)) : 0;
}
const isDm = r => r.cfg.mode === 'dm';
const isFull = r => isDm(r) ? r.players.size >= r.cfg.maxDm : (cnt(r, 'CT') >= r.cfg.perTeam && cnt(r, 'T') >= r.cfg.perTeam);
const aliveN = (r, team) => { let n = 0; for (const p of r.players.values()) if (p.alive && p.team === team) n++; return n; };
const cnt = (room, team) => { let n = 0; for (const p of room.players.values()) if (p.team === team) n++; return n; };
function lobby(room, extra) {
  for (const p of room.players.values()) {
    send(p.ws, Object.assign({
      t: 'lobby', code: room.code, state: room.state, host: room.host, you: p.id,
      players: listPlayers(room), scores: room.scores, target: room.cfg.target, cfg: room.cfg, left: leftSec(room)
    }, extra || {}));
  }
}
function balanceTeam(room) {
  if (isDm(room)) return 'DM';
  const ct = cnt(room, 'CT'), t = cnt(room, 'T');
  if (ct >= room.cfg.perTeam) return 'T';
  if (t >= room.cfg.perTeam) return 'CT';
  return ct <= t ? 'CT' : 'T';
}
function regroup(room) {
  const list = [...room.players.values()];
  if (isDm(room)) { for (const p of list) p.team = 'DM'; room.cfg.maxDm = Math.max(room.cfg.maxDm, list.length); return; }
  room.cfg.perTeam = Math.min(MAX / 2, Math.max(room.cfg.perTeam, Math.ceil(list.length / 2)));
  list.forEach((p, i) => { p.team = i % 2 ? 'T' : 'CT'; });
}
// ---- bomb defusal round machine ----
function bombSnap(r) {
  const b = r.b; if (!b) return null;
  const now = Date.now();
  return { phase: b.phase, n: b.n, left: Math.max(0, Math.ceil((b.endsAt - now) / SEC())), planted: b.planted, site: b.site, bx: b.bx, bz: b.bz,
    bleft: b.planted ? Math.max(0, Math.ceil((b.bombEnds - now) / SEC())) : 0, wins: b.wins, rounds: r.cfg.rounds };
}
function startBombRound(r) {
  const b = r.b; b.n++; b.phase = 'freeze'; b.endsAt = Date.now() + FREEZE * SEC(); b.planted = false; b.site = ''; b.winner = null;
  for (const p of r.players.values()) p.alive = true;
  bcast(r, Object.assign({ t: 'round', ev: 'freeze' }, bombSnap(r)));
}
function bombEnd(r, winner, reason) {
  const b = r.b; if (!b || b.phase === 'end') return;
  b.phase = 'end'; b.endsAt = Date.now() + ENDW * SEC(); b.wins[winner]++; b.winner = winner;
  bcast(r, Object.assign({ t: 'round', ev: 'end', winner, reason }, bombSnap(r)));
}
function bombCheck(r) {
  const b = r.b; if (!b || b.phase !== 'live') return;
  const ca = aliveN(r, 'CT'), ta = aliveN(r, 'T');
  if (b.planted) { if (ca === 0) bombEnd(r, 'T', 'elim'); }
  else if (ta === 0) bombEnd(r, 'CT', 'elim');
  else if (ca === 0) bombEnd(r, 'T', 'elim');
}
function bombTick(r, now) {
  const b = r.b; if (!b) return;
  if (b.phase === 'freeze' && now >= b.endsAt) {
    b.phase = 'live'; b.endsAt = now + ROUND * SEC();
    bcast(r, Object.assign({ t: 'round', ev: 'live' }, bombSnap(r)));
  } else if (b.phase === 'live') {
    if (b.planted) { if (now >= b.bombEnds) bombEnd(r, 'T', 'boom'); }
    else if (now >= b.endsAt) bombEnd(r, 'CT', 'time');
  } else if (b.phase === 'end' && now >= b.endsAt) {
    const w = b.wins.CT >= r.cfg.rounds ? 'CT' : b.wins.T >= r.cfg.rounds ? 'T' : null;
    if (w) finish(r, w); else startBombRound(r);
  }
}
function startPayload(r) {
  const c = r.cfg;
  return { mode: c.mode, target: c.mode === 'bomb' ? c.rounds : c.target, left: leftSec(r), time: c.mode === 'dm' ? DM_MIN : (c.mode === 'tdm' ? c.time : 0), bomb: bombSnap(r) };
}
function finishDm(r) {
  const list = [...r.players.values()].sort((a, b) => b.kills - a.kills);
  const top = list.filter(p => p.kills === (list[0] ? list[0].kills : 0));
  finish(r, 'dm', { topIds: top.map(p => p.id), top: top.map(p => p.name), topKills: list[0] ? list[0].kills : 0, tie: top.length > 1 || !list[0] || list[0].kills === 0 });
}
// ---- virtual accounts (nickname + secret token, no email or password) ----
const DATA = path.join(process.env.DATA_DIR || __dirname, 'accounts.json');
let accounts = {};
try { accounts = JSON.parse(fs.readFileSync(DATA, 'utf8')); } catch (e) { accounts = {}; }
let dirty = false;
setInterval(() => { if (!dirty) return; dirty = false; fs.writeFile(DATA, JSON.stringify(accounts), () => {}); }, 3000).unref();
const hashToken = t => crypto.createHash('sha256').update(t).digest('hex');
const NAME_RE = /^[A-Za-z0-9_-]{3,12}$/;
const online = new Map(); // lowercase name -> socket
const statsOf = a => ({ matches: a.matches, wins: a.wins, kills: a.kills, deaths: a.deaths });
function signIn(ws, key) {
  const old = online.get(key);
  if (old && old !== ws) {
    send(old, { t: 'autherr', code: 'kicked', msg: 'This account signed in somewhere else.' });
    leave(old); old.acct = null; old.key = '';
    old.close();
  }
  ws.acct = accounts[key]; ws.key = key; online.set(key, ws);
}

function leave(ws) {
  const room = ws.room;
  if (!room) return;
  room.players.delete(ws.pid);
  ws.room = null;
  if (room.players.size === 0) { rooms.delete(room.code); return; }
  if (room.host === ws.pid) room.host = room.players.keys().next().value;
  bcast(room, { t: 'left', id: ws.pid });
  if (room.state === 'playing') {
    if (isDm(room)) { if (room.players.size < 2) { finishDm(room); return; } }
    else if (cnt(room, 'CT') === 0 || cnt(room, 'T') === 0) { finish(room, cnt(room, 'CT') === 0 ? 'T' : 'CT'); return; }
    else if (room.cfg.mode === 'bomb') bombCheck(room);
  }
  lobby(room);
}
function finish(room, winner, extra) {
  room.state = 'lobby';
  room.endsAt = 0;
  room.b = null;
  for (const p of room.players.values()) {
    p.alive = true;
    const a = p.ws.acct;
    if (a) {
      a.matches++; a.kills += p.kills; a.deaths += p.deaths;
      if (winner === 'dm' ? (extra && !extra.tie && extra.topIds[0] === p.id) : p.team === winner) a.wins++;
      dirty = true;
    }
  }
  lobby(room, Object.assign({ ended: winner }, extra || {}));
  for (const p of room.players.values()) if (p.ws.acct) send(p.ws, { t: 'account', name: p.ws.acct.name, stats: statsOf(p.ws.acct) });
}
// A skin is either a preset id ({p}) or a small PNG data URL ({s}); anything else is dropped.
function cleanSkin(k) {
  const o = { p: 'team' };
  if (k && typeof k === 'object') {
    if (typeof k.p === 'string' && /^[a-z]{2,10}$/.test(k.p)) o.p = k.p;
    if (typeof k.s === 'string' && k.s.length <= 24000 && /^data:image\/png;base64,[A-Za-z0-9+\/=]+$/.test(k.s)) o.s = k.s;
  }
  return o;
}
const num = v => (Number.isFinite(+v) ? +v : 0);

function onConnection(ws) {
  ws.pid = nextId++;
  ws.room = null;
  ws.acct = null;
  ws.key = '';

  ws.on('message', raw => {
    let m;
    try { m = JSON.parse(raw); } catch (e) { return; }
    if (!m || typeof m.t !== 'string') return;
    const room = ws.room;
    const me = room && room.players.get(ws.pid);

    switch (m.t) {
      case 'register': {
        if (ws.acct) return;
        ws.regs = (ws.regs || 0) + 1;
        if (ws.regs > 8) { send(ws, { t: 'autherr', code: 'limit', msg: 'Too many attempts. Reload the page.' }); return; }
        const name = String(m.name || '').trim();
        if (!NAME_RE.test(name)) { send(ws, { t: 'autherr', code: 'badname', msg: 'Use 3 to 12 letters, numbers, _ or -.' }); return; }
        const key = name.toLowerCase();
        if (accounts[key]) { send(ws, { t: 'autherr', code: 'taken', msg: 'That nickname is taken. Try another.' }); return; }
        if (Object.keys(accounts).length >= 20000) { send(ws, { t: 'autherr', code: 'full', msg: 'The server cannot take more accounts right now.' }); return; }
        const token = crypto.randomBytes(16).toString('hex');
        accounts[key] = { name, hash: hashToken(token), created: Date.now(), matches: 0, wins: 0, kills: 0, deaths: 0 };
        dirty = true;
        signIn(ws, key);
        send(ws, { t: 'account', name, token, stats: statsOf(accounts[key]) });
        break;
      }
      case 'login': {
        if (ws.acct) return;
        ws.tries = (ws.tries || 0) + 1;
        if (ws.tries > 20) { ws.close(); return; }
        const key = String(m.name || '').toLowerCase();
        const a = accounts[key];
        if (!a || a.hash !== hashToken(String(m.token || ''))) { send(ws, { t: 'autherr', code: 'badtoken', msg: 'This account is no longer valid. Create a new one.' }); return; }
        signIn(ws, key);
        send(ws, { t: 'account', name: a.name, stats: statsOf(a) });
        break;
      }
      case 'create':
      case 'join': {
        if (room) return;
        if (!ws.acct) { send(ws, { t: 'autherr', code: 'noauth', msg: 'Sign in first.' }); return; }
        let r;
        if (m.t === 'create') {
          r = { code: newCode(), players: new Map(), host: ws.pid, state: 'lobby', scores: { CT: 0, T: 0 }, cfg: Object.assign({}, DEFCFG), endsAt: 0, b: null };
          rooms.set(r.code, r);
        } else {
          r = rooms.get(String(m.code || '').toUpperCase());
          if (!r) { send(ws, { t: 'error', msg: 'Room not found. Check the code.' }); return; }
          if (isFull(r)) { send(ws, { t: 'error', msg: 'Room is full.' }); return; }
        }
        r.players.set(ws.pid, { id: ws.pid, ws, name: ws.acct.name, team: balanceTeam(r), kills: 0, deaths: 0, alive: !(r.state === 'playing' && r.b && r.b.phase !== 'freeze'), skin: cleanSkin(m.skin) });
        ws.room = r;
        lobby(r);
        if (r.state === 'playing') send(ws, Object.assign({ t: 'start' }, startPayload(r)));
        break;
      }
      case 'leave': leave(ws); break;
      case 'team': {
        if (!me || room.state !== 'lobby' || isDm(room)) break;
        const want = m.team === 'CT' || m.team === 'T' ? m.team : (me.team === 'CT' ? 'T' : 'CT');
        if (want === me.team) break;
        if (cnt(room, want) >= room.cfg.perTeam) { send(ws, { t: 'error', msg: 'That team is full.' }); break; }
        me.team = want;
        lobby(room);
        break;
      }
      case 'skin': {
        if (!me || room.state !== 'lobby') break;
        me.skin = cleanSkin(m.skin);
        lobby(room);
        break;
      }
      case 'cfg': {
        if (!me || room.host !== ws.pid || room.state !== 'lobby') break;
        const c = room.cfg;
        if (MODES.includes(m.mode) && m.mode !== c.mode) { c.mode = m.mode; regroup(room); }
        const big = Math.max(cnt(room, 'CT'), cnt(room, 'T'));
        const pt = Math.round(num(m.perTeam)), tm = Math.round(num(m.time)), tg = Math.round(num(m.target)), rd = Math.round(num(m.rounds)), md = Math.round(num(m.maxDm));
        if (!isDm(room) && pt >= 1 && pt <= MAX / 2) c.perTeam = Math.max(pt, big);
        if ([0, 5, 10, 15].includes(tm)) c.time = tm;
        if ([10, 20, 30].includes(tg)) c.target = tg;
        if ([3, 5, 7].includes(rd)) c.rounds = rd;
        if ([2, 4, 6, 8].includes(md)) c.maxDm = Math.max(md, room.players.size);
        lobby(room);
        break;
      }
      case 'start': {
        if (!me || room.host !== ws.pid || room.state !== 'lobby') break;
        const ready = isDm(room) ? room.players.size >= 2 : (cnt(room, 'CT') >= 1 && cnt(room, 'T') >= 1);
        if (!ready) break;
        room.state = 'playing';
        room.scores = { CT: 0, T: 0 };
        const mode = room.cfg.mode;
        room.endsAt = mode === 'dm' ? Date.now() + DM_MIN * (Number(process.env.TSG_MIN_MS) || 60000)
          : mode === 'tdm' && room.cfg.time ? Date.now() + room.cfg.time * (Number(process.env.TSG_MIN_MS) || 60000) : 0;
        room.b = mode === 'bomb' ? { phase: 'freeze', n: 0, endsAt: 0, planted: false, site: '', bx: 0, bz: 0, bombEnds: 0, wins: { CT: 0, T: 0 }, winner: null } : null;
        for (const p of room.players.values()) { p.kills = 0; p.deaths = 0; p.alive = true; }
        lobby(room);
        bcast(room, Object.assign({ t: 'start' }, startPayload(room)));
        if (room.b) startBombRound(room);
        break;
      }
      case 's': {
        if (!me || room.state !== 'playing') break;
        bcast(room, { t: 's', id: me.id, x: num(m.x), y: num(m.y), z: num(m.z), yaw: num(m.yaw), a: m.a ? 1 : 0, w: String(m.w || '').slice(0, 6) }, me.id);
        break;
      }
      case 'shot': {
        if (!me || room.state !== 'playing' || !me.alive) break;
        bcast(room, { t: 'shot', id: me.id, ex: num(m.ex), ey: num(m.ey), ez: num(m.ez), w: String(m.w || '').slice(0, 6) }, me.id);
        break;
      }
      case 'hit': {
        if (!me || room.state !== 'playing' || !me.alive) break;
        const t = room.players.get(m.to);
        if (!t || t.id === me.id || (room.cfg.mode !== 'dm' && t.team === me.team) || !t.alive) break;
        send(t.ws, { t: 'hit', from: me.id, dmg: Math.min(200, Math.max(0, num(m.dmg))), head: !!m.head, w: String(m.w || '').slice(0, 10) });
        break;
      }
      case 'died': {
        if (!me || room.state !== 'playing' || !me.alive) break;
        me.alive = false;
        me.deaths++;
        const mode = room.cfg.mode;
        const k = room.players.get(m.by);
        if (k && k.id !== me.id && (mode === 'dm' || k.team !== me.team)) { k.kills++; if (mode === 'tdm') room.scores[k.team]++; }
        const out = { t: 'kill', killer: k ? k.id : 0, victim: me.id, w: String(m.w || '').slice(0, 10), head: !!m.head, scores: mode === 'bomb' && room.b ? room.b.wins : room.scores };
        if (mode === 'dm') { out.kills = {}; for (const p of room.players.values()) out.kills[p.id] = p.kills; }
        bcast(room, out);
        if (mode === 'tdm') { for (const team of ['CT', 'T']) if (room.scores[team] >= room.cfg.target) { finish(room, team); break; } }
        else if (mode === 'bomb') bombCheck(room);
        break;
      }
      case 'respawn': {
        if (me && room.cfg.mode !== 'bomb') me.alive = true;
        break;
      }
      case 'plant': {
        const b = room && room.b;
        if (!me || !b || b.phase !== 'live' || b.planted || !me.alive || me.team !== 'T') break;
        b.planted = true; b.site = m.site === 'B' ? 'B' : 'A'; b.bx = num(m.x); b.bz = num(m.z); b.bombEnds = Date.now() + BOMB * SEC();
        bcast(room, { t: 'bomb', ev: 'planted', site: b.site, x: b.bx, z: b.bz, left: BOMB, by: me.id });
        break;
      }
      case 'defuse': {
        const b = room && room.b;
        if (!me || !b || b.phase !== 'live' || !b.planted || !me.alive || me.team !== 'CT') break;
        bcast(room, { t: 'bomb', ev: 'defused', by: me.id });
        bombEnd(room, 'CT', 'defused');
        break;
      }
      default: break; // 'ping' and unknown messages are ignored
    }
  });

  ws.on('close', () => { leave(ws); if (ws.key && online.get(ws.key) === ws) online.delete(ws.key); });
  ws.on('error', () => {});
}

// time limits (tdm: team with more kills, dm: most kills) and the bomb round machine
setInterval(() => {
  const now = Date.now();
  for (const room of [...rooms.values()]) {
    if (room.state !== 'playing') continue;
    if (room.cfg.mode === 'bomb') { bombTick(room, now); continue; }
    if (room.endsAt && now >= room.endsAt) {
      if (room.cfg.mode === 'dm') finishDm(room);
      else { const d = room.scores.CT - room.scores.T; finish(room, d > 0 ? 'CT' : d < 0 ? 'T' : 'draw'); }
    }
  }
}, 250).unref();

server.listen(PORT, () => console.log('Testshootinggame listening on ' + PORT));
