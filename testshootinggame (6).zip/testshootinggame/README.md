# Testshootinggame on Netlify

Two parts:

1. `netlify-site/` is the game page. It is a static site, so Netlify hosts it. Solo mode works with nothing else.
2. `realtime-server/` is the small Node server for online rooms and accounts (no npm dependencies).

Netlify cannot run part 2. Online rooms need a WebSocket connection that stays open, and Netlify Functions are short-lived and do not accept WebSockets. Keep the server on Render (free plan) or any host that runs Node (Railway, Fly.io, a VPS).

## Deploy the page on Netlify
- Easiest: open https://app.netlify.com/drop and drag the `netlify-site` folder onto it.
- Or push `netlify-site` to GitHub, then Netlify > Add new site > Import from Git. Build command: empty. Publish directory: `.`

## Deploy the server on Render
1. Push `realtime-server` to a GitHub repo.
2. Render > New > Web Service (Node). Build `npm install`, Start `node server.js`.
3. Copy the address, for example `https://testshootinggame.onrender.com`.

## Connect the two
Open the Netlify site > Settings > ONLINE > paste the server address (wss:// or https:// both work) > SAVE > TEST.
Invite links created in a room include the server address, so friends need no setup.

To bake the address into the page for everyone, edit `index.html` and change `window.TSG_SERVER=""` to `window.TSG_SERVER="wss://testshootinggame.onrender.com"`, then redeploy.

## Notes
- Render's free plan sleeps after about 15 minutes idle and needs about a minute to wake. The first online action after a pause can be slow.
- Accounts are stored in `accounts.json` next to the server. On Render's free plan it is wiped on each deploy or restart; set `DATA_DIR` to a persistent disk to keep it.
- Rooms live in memory. Run a single instance.
